# iOS Wwise Unity Build module
import BuildUtil
import BuildWwiseUnityIntegration
import GenerateApiBinding
import collections
from os import path
from BuildWwiseUnityIntegration import XCodeBuilder
from GenerateApiBinding import AppleSwigCommand
from PrepareSwigInput import SwigPlatformHandlerPOSIX, SwigApiHeaderBlobber, PlatformStructProfile

class iOSBuilder(XCodeBuilder):
	def __init__(self, platformName, arches, configs, generateSwig, generatePremake):
		XCodeBuilder.__init__(self, platformName, arches, configs, generateSwig, generatePremake)

class iOSSwigCommand(AppleSwigCommand):
	def __init__(self, pathMan):
		AppleSwigCommand.__init__(self, pathMan)

		self.platformDefines += ['-DAK_IOS', '-DTARGET_OS_IPHONE', '-DTARGET_OS_EMBEDDED', '-D__arm__'] # No need for -D__arm64__. __arm__ is good enough for fixing header includes on iOS7.
		self.dllName = ['-dllimport', '__Internal']

		self.platformSdkName = 'iPhoneOS'
		self._InitPlatformSdkInfo()

class SwigApiHeaderBlobberiOS(SwigApiHeaderBlobber):
	def __init__(self, pathMan):
		SwigApiHeaderBlobber.__init__(self, pathMan)

		self.inputHeaders.append(path.normpath(path.join(self.SdkIncludeDir, 'AK/SoundEngine/Platforms/iOS/AkiOSSoundEngine.h')))

class SwigPlatformHandleriOS(SwigPlatformHandlerPOSIX):
	def __init__(self, pathMan):
		SwigPlatformHandlerPOSIX.__init__(self, pathMan)

		AudioSessionPropertyHeader = 'AK/SoundEngine/Platforms/iOS/AkiOSSoundEngine.h'
		AudioSessionRegEx = '(struct[ \t]+AkAudioSessionProperties)([\w\W]*?)(\};)'
		self.PlatformStructProfiles += \
		[
			PlatformStructProfile(self.pathMan, AudioSessionPropertyHeader, AudioSessionRegEx)
		]
		
		self.ioFileSources += \
		[
			path.join(self.pathMan.Paths['Wwise_SDK_Samples'], 'SoundEngine', 'iOS', 'AkFileHelpersiOS.h'),
		]

def Init(argv=None):
	BuildUtil.BankPlatforms['iOS'] = 'iOS'
	BuildUtil.PremakeParameters['iOS'] = { 'os': 'ios', 'generator': 'xcode4' }
	BuildUtil.PlatformSwitches['iOS'] = '#if UNITY_IOS && ! UNITY_EDITOR'
	BuildUtil.PlatformDependentFilenames.append('AkAudioSessionCategory.cs')
	BuildUtil.PlatformDependentFilenames.append('AkAudioSessionCategoryOptions.cs')
	BuildUtil.PlatformDependentFilenames.append('AkAudioSessionMode.cs')
	BuildUtil.PlatformDependentFilenames.append('AkAudioSessionProperties.cs')
	BuildUtil.PlatformDependentFilenames.append('AkAudioSessionSetActiveOptions.cs')
	BuildUtil.PlatformDependentFilenames.append('AkAudioSessionBehaviorOptions.cs')
	BuildUtil.SupportedPlatforms['Darwin'].append('iOS')

def CreatePlatformBuilder(platformName, arches, configs, generateSwig, generatePremake):
	return iOSBuilder(platformName, arches, configs, generateSwig, generatePremake)

def CreateSwigCommand(pathMan, arch):
	return iOSSwigCommand(pathMan)

def CreateSwigPlatformHandler(pathMan):
	return SwigPlatformHandleriOS(pathMan)

def CreateSwigApiHeaderBlobber(pathMan):
	return SwigApiHeaderBlobberiOS(pathMan)

if __name__ == '__main__':
	pass
